<?php

include 'config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['productionStage'])) {
        $productionStage = $_POST['productionStage'];
    } else {
        // Set a default value if no option is selected
        $productionStage = 1;
    }

    // Define the table names based on the selected production stage
    $tableNames = [
        1 => 'printings',
        2 => 'pcbs',
        3 => 'monitorassembly',
        4 => 'configurations',
        5 => 'testings',
        6 => 'targets'
    ];

    // Check if the selected production stage exists in the tableNames array
    if (isset($tableNames[$productionStage])) {
        $tableName = $tableNames[$productionStage];
    } else {
        // Set a default table name if the selected production stage is invalid
        $tableName = 'targets';
    }

    // Handle form input values


    if (isset($_POST['datetime'])) {
        $datetime = $_POST['datetime'];
    } else {
        // Handle the error condition when datetime is not set
        echo "Error: Datetime is not set.";
        exit();
    }


    if (isset($_POST['qty'])) {
        $qty = $_POST['qty'];
    } else {
        // Handle the error condition when qty is not set
        echo "Error: Quantity is not set.";
        exit();
    }

    if (isset($_POST['eventdetail'])) {
        $eventdetail = $_POST['eventdetail'];
    } else {
        // Handle the error condition when eventdetail is not set
        echo "Error: Event Detail is not set.";
        exit();
    }

}
?>
