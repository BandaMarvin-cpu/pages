<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
// Database connection details

$host = 'localhost';

$dbname = 'crud_example';

$username = 'root';

$password = '6C7VpCjhDDb8';


// Establish a database connection

$conn = new mysqli($host, $username, $password, $dbname);

if ($conn->connect_error) {

    die("Connection failed: " . $conn->connect_error);

}


// Handle form submission for creating a new record

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    if (isset($_POST['submit'])) {

        $deliverable = $_POST['deliverable'];

        $datetime = $_POST['datetime'];

        $supervisor = $_POST['supervisor'];


        $insertSql = "INSERT INTO targets (deliverable, datetime, supervisor) VALUES ('$deliverable', '$datetime', '$supervisor')";

        if ($conn->query($insertSql) === TRUE) {

            echo "Record created successfully.";

        } else {

            echo "Error creating record: " . $conn->error;

        }

    }

}


// Handle record deletion

if (isset($_GET['action']) && $_GET['action'] === 'delete') {

    if (isset($_GET['id'])) {

        $id = $_GET['id'];

        echo "Deleting record with ID: " . $id . "<br>";


        $deleteSql = "DELETE FROM targets WHERE target_id = $id";

        if ($conn->query($deleteSql) === TRUE) {

            echo "Record deleted successfully.";

        } else {

            echo "Error deleting record: " . $conn->error;

        }

    }

}


// Handle record update

if (isset($_POST['update'])) {

    $id = $_POST['id'];

    $deliverable = $_POST['deliverable'];

    $datetime = $_POST['datetime'];

    $supervisor = $_POST['supervisor'];


    $updateSql = "UPDATE targets SET deliverable = '$deliverable', datetime = '$datetime', supervisor = '$supervisor' WHERE target_id = $id";

    if ($conn->query($updateSql) === TRUE) {

        echo "Record updated successfully.";

    } else {

        echo "Error updating record: " . $conn->error;

    }

}


// Retrieve records from the database

$sql = "SELECT target_id, deliverable, datetime, supervisor FROM targets";

$result = $conn->query($sql);

if (!$result) {

    die("Query failed: " . $conn->error);

}


// Display the records in a table

$tableRows = '';

if ($result->num_rows > 0) {

    while ($row = $result->fetch_assoc()) {

        $target_id = $row['target_id'];

        $deliverable = $row['deliverable'];

        $datetime = $row['datetime'];

        $supervisor = $row['supervisor'];


        $tableRows .= '<tr>';

        $tableRows .= '<td>' . $target_id . '</td>';

        $tableRows .= '<td>' . $deliverable . '</td>';

        $tableRows .= '<td>' . $datetime . '</td>';

        $tableRows .= '<td>' . $supervisor . '</td>';

        $tableRows .= '<td>';

        $tableRows .= '<a href="?action=edit&id=' . $target_id . '">Edit</a> ';

        $tableRows .= '<a href="?action=delete&id=' . $target_id . '" onclick="return confirm(\'Are you sure you want to delete this record?\')">Delete</a>';

        $tableRows .= '</td>';

        $tableRows .= '</tr>';

    }

}


$conn->close();

?>


<!DOCTYPE html>

<html>

<head>

    <title>CRUD Page</title>

</head>

<body>

    <h1>CRUD Page</h1>


    <h2>Create</h2>

    <form method="post" action="">

        <input type="text" name="deliverable" placeholder="Deliverable" required>

        <input type="text" name="datetime" placeholder="Datetime" required>

        <input type="text" name="supervisor" placeholder="Supervisor" required>

        <input type="submit" name="submit" value="Create">

    </form>


    <h2>Read</h2>

    <table>

        <thead>

            <tr>

                <th>ID</th>

                <th>Deliverable</th>

                <th>Datetime</th>

                <th>Supervisor</th>

                <th>Actions</th>

            </tr>

        </thead>

        <tbody>

            <?php echo $tableRows; ?>

        </tbody>

    </table>


    <?php if (isset($_GET['action']) && $_GET['action'] === 'edit') : ?>

        <?php

        $editId = $_GET['id'];

        $editSql = "SELECT target_id, deliverable, datetime, supervisor FROM targets WHERE target_id = $editId";

        $editResult = $conn->query($editSql);

        if ($editResult && $editResult->num_rows > 0) {

            $editRow = $editResult->fetch_assoc();

            $editDeliverable = $editRow['deliverable'];

            $editDatetime = $editRow['datetime'];

            $editSupervisor = $editRow['supervisor'];

        }

        ?>


        <h2>Edit</h2>

        <form method="post" action="">

            <input type="hidden" name="id" value="<?php echo $editId; ?>">

            <input type="text" name="deliverable" placeholder="Deliverable" value="<?php echo $editDeliverable; ?>" required>

            <input type="text" name="datetime" placeholder="Datetime" value="<?php echo $editDatetime; ?>" required>

            <input type="text" name="supervisor" placeholder="Supervisor" value="<?php echo $editSupervisor; ?>" required>

            <input type="submit" name="update" value="Update">

        </form>

    <?php endif; ?>


</body>

</html>

