<!DOCTYPE html>

<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Airqo Hardware Production</title>
  <!-- plugins:css -->
   <link rel="stylesheet" href="vendors/iconfonts/font-awesome/css/all.min.css">
  <link rel="stylesheet" href="vendors/css/vendor.bundle.base.css">
  <link rel="stylesheet" href="vendors/css/vendor.bundle.addons.css">

  <link rel="stylesheet" href="css/x.css">
  <!-- endinject -->
  <link rel="shortcut icon" href="images/logo.png" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
    
    <link rel="stylesheet" href="css/x.css">
    <link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Kalam&display=swap" rel="stylesheet">

    <script defer src="script.js"></script> 
</head>

<body>
  <div class="container-scroller">
    <!-- partial:partials/_navbar.html -->
    <nav class="navbar col-lg-12 col-12 p-0 fixed-top d-flex flex-row default-layout-navbar">
      <div class="text-center navbar-brand-wrapper d-flex align-items-center justify-content-center">
        <img src="images/logo.png" width= "20%" boarder-radius="3cm" alt=" "/>
        <img src="images/mak_logo.png" width= "21%" boarder-radius="3cm" alt=" "/>
      </div>
      <div class="navbar-menu-wrapper d-flex align-items-stretch">
        
        <button class="navbar-toggler navbar-toggler align-self-center" type="button" data-toggle="minimize">
          <span class="fas fa-bars"></span>
        </button>
      

      

        
        <ul class="navbar-nav">
          <li class="nav-item nav-search d-none d-md-flex">
            <div class="nav-link">
              <div class="input-group">
                <div class="input-group-prepend">
                  <span class="input-group-text">
                    <i class="fas fa-search"></i>
                  </span>
                </div>
                <input type="text" class="form-control" placeholder=".." aria-label="Search">
              </div>
            </div>
          </li>
        </ul>
        <ul class="navbar-nav navbar-nav-right">
          <li class="nav-item dropdown d-none d-lg-flex">
            <div class="nav-link">
             
            </div>
            
               <div id="MyClockDisplay" class="clock" onload="showTime()"></div>

    
          </li>


          <li class="nav-item nav-settings d-none d-lg-block">
            <a class="nav-link" href="#">
              <i class="fas fa-ellipsis-h"></i>
            </a>
          </li>

          <li class="nav-item nav-profile dropdown">
            <a class="nav-link dropdown-toggle" href="#" data-toggle="dropdown" id="profileDropdown">
              ll
            </a>
            <div class="dropdown-menu dropdown-menu-right navbar-dropdown" aria-labelledby="profileDropdown">
              <a class="dropdown-item">
                <i class="fas fa-cog text-primary"></i>
                Account settings
              </a>
              <div class="dropdown-divider"></div>
              <a class="dropdown-item">
                <i class="fas fa-power-off text-primary"></i>
                Log Out
              </a>
            </div>
          </li>
        </ul>
        <button class="navbar-toggler navbar-toggler-right d-lg-none align-self-center" type="button" data-toggle="offcanvas">
          <span class="fas fa-bars"></span>
        </button>
      </div>
    </nav>

                <div class="dropdown-menu dropdown-menu-right navbar-dropdown preview-list" aria-labelledby="notificationDropdown">
              <a class="dropdown-item">
                <p class="mb-0 font-weight-normal float-left">You have 16 new notifications
                </p>
                <span class="badge badge-pill badge-warning float-right">View all</span>
              </a>
              <div class="dropdown-divider"></div>
              <a class="dropdown-item preview-item">
                
              </a>
              <div class="dropdown-divider"></div>
              <a class="dropdown-item preview-item">
                <div class="preview-thumbnail">
                  <div class="preview-icon bg-warning">
                    <i class="fas fa-wrench mx-0"></i>
                  </div>
                </div>
                <div class="preview-item-content">
                  <h6 class="preview-subject font-weight-medium">Settings</h6>
                  <p class="font-weight-light small-text">
                    procurement
                  </p>
                </div>
              </a>
              <div class="dropdown-divider"></div>
              <a class="dropdown-item preview-item">
                <div class="preview-thumbnail">
                  <div class="preview-icon bg-info">
                    <i class="far fa-envelope mx-0"></i>
                  </div>
                </div>
 
              </a>
            </div>
    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
      <!-- partial:partials/_settings-panel.html -->
      <div class="theme-setting-wrapper">
        <div id="settings-trigger" style="margin-left: 0cm;"><i class="fas fa-fill-drip"></i></div>
        <div id="theme-settings" class="settings-panel">
          <i class="settings-close fa fa-times"></i>
          <p class="settings-heading">SIDEBAR SKINS</p>
          <div class="sidebar-bg-options selected" id="sidebar-light-theme"><div class="img-ss rounded-circle bg-light border mr-3"></div>Light</div>
          <div class="sidebar-bg-options" id="sidebar-dark-theme"><div class="img-ss rounded-circle bg-dark border mr-3"></div>Dark</div>
          <p class="settings-heading mt-2">HEADER SKINS</p>
          <div class="color-tiles mx-0 px-4">
            <div class="tiles primary"></div>
            <div class="tiles success"></div>
            <div class="tiles warning"></div>
            <div class="tiles danger"></div>
            <div class="tiles info"></div>
            <div class="tiles dark"></div>
            <div class="tiles default"></div>
          </div>
        </div>
      </div>
      <div id="right-sidebar" class="settings-panel">
        <i class="settings-close fa fa-times"></i>
        <ul class="nav nav-tabs" id="setting-panel" role="tablist">
          <li class="nav-item">
            <a class="nav-link active" id="todo-tab" data-toggle="tab" href="#todo-section" role="tab" aria-controls="todo-section" aria-expanded="true">TO DO LIST</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" id="chats-tab" data-toggle="tab" href="#chats-section" role="tab" aria-controls="chats-section">deadlines</a>
          </li>
        </ul>
        <div class="tab-content" id="setting-content">
          <div class="tab-pane fade show active scroll-wrapper" id="todo-section" role="tabpanel" aria-labelledby="todo-section">
            <div class="add-items d-flex px-3 mb-0">
              <form class="form w-100">
                <div class="form-group d-flex">
                  <input type="text" class="form-control todo-list-input" placeholder="Add To-do">
                  <button type="submit" class="add btn btn-primary todo-list-add-btn" id="add-task-todo">Add</button>
                </div>
              </form>
            </div>
            <div class="list-wrapper px-3">
              <ul class="d-flex flex-column-reverse todo-list">
                <li>
       
                  <i class="remove fa fa-times-circle"></i>
                </li>
  
 
              </ul>
            </div>
            <div class="events py-4 border-bottom px-3">
              <div class="wrapper d-flex mb-2">
                <i class="fa fa-times-circle text-primary mr-2"></i>
                <span>time of ordering, </span>
              </div>
              <p class="mb-0 font-weight-thin text-gray">Callibration Vs.. PreDeploymentAnalysis</p>
              <p class="text-gray mb-0">progress bar</p>
            </div>
          </div>
          <!-- To do section tab ends -->
          <div class="tab-pane fade" id="chats-section" role="tabpanel" aria-labelledby="chats-section">
            <div class="d-flex align-items-center justify-content-between border-bottom">
              <p class="settings-heading border-top-0 mb-3 pl-3 pt-0 border-bottom-0 pb-0">action-time-planning</p>
              <small class="settings-heading border-top-0 mb-3 pt-0 border-bottom-0 pb-0 pr-3 font-weight-normal">See All</small>
            </div>

          </div>
          <!-- chat tab ends -->
        </div>
      </div>
      <!-- partial -->
      <!-- partial:partials/_sidebar.html -->
      <nav class="sidebar sidebar-offcanvas" id="sidebar">
        <ul class="nav">
          <li class="nav-item nav-profile">
            <div class="nav-link">
              <div class="profile-image">
                <img src="images/faces/spiderman2.jpg" alt="image"/>
              </div>
              <div class="profile-name">
                <p class="name">
                  Welcome  User
                </p>
                <p class="designation">
                  Embbeded Systems 
                </p>
              </div>
            </div>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="index.php">
              <i class="fa fa-home menu-icon"></i>
              <span class="menu-title">Home</span>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="Targets.php">
              <i class="fa fa-home menu-icon"></i>
              <span class="menu-title">Targets</span>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="Batches.php">
              <i class="fa fa-home menu-icon"></i>
              <span class="menu-title">Batches</span>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="Reports.php">
              <i class="fa fa-puzzle-piece menu-icon"></i>
              <span class="menu-title">Reports</span>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" data-toggle="collapse" href="#page-layouts" aria-expanded="false" aria-controls="page-layouts">
              <i class="fab fa-trello menu-icon"></i>
              <span class="menu-title">StockTake_Tool</span>
              <i class="menu-arrow"></i>
            </a>
            <div class="collapse" id="page-layouts">
              <ul class="nav flex-column sub-menu">
                <li class="nav-item d-none d-lg-block"> <a class="nav-link" href="devices.php">Devices</a></li>
                <li class="nav-item d-none d-lg-block"> <a class="nav-link" href="Stocktake.php">Lab Inventory</a></li>
                <li class="nav-item d-none d-lg-block"> <a class="nav-link" href="bom.php">BOM</a></li>
              </ul>
            </div>
          </li>
        

           <li class="nav-item">
            <a class="nav-link" href="documentation.php">
              <i class="far fa-file-alt menu-icon"></i>
              <span class="menu-title">Documentation</span>
            </a>
           </li>

                      <li class="nav-item">
            <a class="nav-link" href="mylinks.php">
              <i class="far fa-file-alt menu-icon"></i>
              <span class="menu-title">links</span>
            </a>
           </li>
        </ul>
      </nav>
      <!-- partial -->
      <div class="main-panel">
        <div class="content-wrapper">
          <div class="page-header">
                
             </div>


             
               
             <br><br><br><br>        

<input></input>
<button>Search </button><br><br>
<h6>SumationOfDoneDones</h6>

<p>Picked from DoneDone to PCB Phase 3</p> 
               <html>
          
 
              <div class="row grid-margin">
             <div class="col-4">
                  <div class="d-flex flex-column flex-md-row align-items-center justify-content-between">




                  <div class="table-wrapper"> 
                  <?php
    // Step 1: Include the config file
    include 'config.php';



    // Step 3: Check if delete action is requested
    if (isset($_GET['action']) && $_GET['action'] === 'delete') {
        if (isset($_GET['id'])) {
            $index = $_GET['id'];
            // Perform the delete action using $index
            // Replace the following line with your own delete logic
            echo "Deleting row with index: " . $id . "<br>";
        }
    }

    // Step 4: Query the database to fetch data
    $sql = "SELECT `device_id`, devicename, location FROM devices";
    $result = $conn->query($sql);

    // Step 5: Check if the query was successful
    if (!$result) {
        die("Query failed: " . $conn->error);
    }

    // Step 6: Iterate over the fetched data and generate HTML table rows
    $tableRows = '';
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $id = $row['id'];
            $tableRows .= '<tr>';
            foreach ($row as $cell) {
                $tableRows .= '<td>' . $cell . '</td>';
            }
            // Add Edit and Delete buttons for each row
            $tableRows .= '<td>';
            $tableRows .= '<a href="edit.php?index=' . $id . '">Edit</a> ';
            $tableRows .= '<a href="#" onclick="confirmDelete(' . $id . ');">Delete</a>';
            $tableRows .= '</td>';
            $tableRows .= '</tr>';
        }
    }

    // Step 7: Output the HTML table to the browser
    echo '<table>';
    echo '<thead><tr><th>id</th><th>Device</th><th>Location</th><th>Status</th><th>number</th></tr></thead>';
    echo '<tbody>' . $tableRows . '</tbody>';
    echo '</table>';

    // Step 8: Close the database connection
    $conn->close();
    ?>
                  

           
                
             
          </div>






<footer class="footer">  
          hjgkjhg          
                  </footer>

    <script src="/script.js"></script>
  <!-- container-scroller -->
  <script>
    function openForm() {
      document.getElementById("myForm").style.display = "block";
    }


    function openpcbForm() {
      document.getElementById("myForm").style.display = "block";
    }
    
    function closeForm() {
      document.getElementById("myForm").style.display = "none";
    }
    </script>
  <!-- plugins:js -->
  <script>function showTime(){
    var date = new Date();
    var h = date.getHours(); // 0 - 23
    var m = date.getMinutes(); // 0 - 59
    var s = date.getSeconds(); // 0 - 59
    var session = "AM";
    
    if(h == 0){
        h = 12;
    }
    
    if(h > 12){
        h = h - 12;
        session = "PM";
    }
    
    h = (h < 10) ? "0" + h : h;
    m = (m < 10) ? "0" + m : m;
    s = (s < 10) ? "0" + s : s;
    
    var time = h + ":" + m + ":" + s + " " + session;
    document.getElementById("MyClockDisplay").innerText = time;
    document.getElementById("MyClockDisplay").textContent = time;
    
    setTimeout(showTime, 1000);
    
}

showTime();</script>
  <script src="vendors/js/vendor.bundle.base.js"></script>
  <script src="vendors/js/vendor.bundle.addons.js"></script>
  <!-- endinject -->
  <!-- Plugin js for this page-->
  <!-- End plugin js for this page-->
  <!-- inject:js -->
  <script src="js/chart.js"></script>
  <script src="js/progress.js"></script>
  <script src="js/off-canvas.js"></script>
  <script src="js/hoverable-collapse.js"></script>
  <script src="js/misc.js"></script>
  <script src="js/settings.js"></script>
  <script src="js/todolist.js"></script>
  <script src="js/3d.js"></script>
  <script defer src="js/xylo.js"></script> 
  <!-- endinject -->
  <!-- Custom js for this page-->
  <script src="js/dashboard.js"></script>
  <!-- End custom js for this page-->
  <script  src="./script.js"></script>

  
</body>

</html>







