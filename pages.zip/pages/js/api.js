const axios = require('axios');
const apiKey = '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';
const requestConfig = {
  headers: {
    'Authorization': `Bearer ${apiKey}`
  }
};

axios.get('https://api.openai.https://api.openai.com/v1/engines/davinci-codex/completions/v1/your-endpoint', requestConfig)
  .then(response => {
    // Handle the API response
    console.log(response.data);
  })
  .catch(error => {
    // Handle errors
    console.error(error);
  });
